export const message1 = 'asdasd';
export const message2 = 'message2';
