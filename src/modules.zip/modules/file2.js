import message1 from './file1';
import message2 from './file1';

const alertMessages = (message = 'initial message') => {
  alert(message);
};

alertMessages(message1);
alertMessages(message2);
